package pwc;


import java.io.IOException;
import java.time.Duration;
import java.util.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class bookTicket {
	static WebDriver driver;

	@Test
	public  void validationMmt() throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:/Users/91993/Downloads/chromedriver_win32 (2)/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		//FileInputStream fis=new FileInputStream("/pwc/src/test/java/pwc/config.properties");
		//Properties prop= new Properties();
		//prop.load(fis);
		
		//driver.get(prop.getProperty("url"));
		driver.findElement(By.xpath("//span[contains(@class,'chFlight')]")).click();
		driver.findElement(By.xpath("(//span[contains(@class,'tabsCircle appendRight5')])[1]")).click();
		
		WebElement e=driver.findElement(By.xpath("//input[@id='fromCity']"));
		e.sendKeys("Mum");
		
		driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-0\"]/div/div[1]/p[1]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[contains(@placeholder,'To')]")).sendKeys("Pune"); 
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//p[contains(text(),'Pune, India')]")).click();
		 
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'DEPARTURE')]")).click();
		
		
		
		
		driver.findElement(By.xpath("//div[@aria-label=\"Tue Jun 21 2022\"]")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'Search')]")).click();
		
		driver.navigate().to("https://www.makemytrip.com/flight/search?itinerary=BOM-PNQ-21/06/2022&tripType=O&paxType=A-1_C-0_I-0&intl=false&cabinClass=E&ccde=IN&lang=eng");
		//driver.findElement(By.xpath("//button[text()='OKAY, GOT IT!']")).click();
       //Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[text()='View Prices'])[1]")).click();
		driver.findElement(By.xpath("(//button[contains(@class,'button corp-btn latoBlack buttonPrimary fontSize13')])[1]")).click();
		String mainWindow=driver.getWindowHandle();
		Set<String> s= driver.getWindowHandles();
		Iterator<String> i1=s.iterator();
		while(i1.hasNext())
		{
			String Child_w=i1.next();
			if(!mainWindow.equalsIgnoreCase(Child_w))
			{
				driver.switchTo().window(Child_w);
			
			}
		}
		WebElement ActualText=driver.findElement(By.xpath("//span[text()='Total Amount']"));
		SoftAssert s1=new SoftAssert();
		s1.assertEquals(ActualText, "Total Amount");
		{
			System.out.println("total amount text is present");
		}
		
		driver.quit();
	}

}
